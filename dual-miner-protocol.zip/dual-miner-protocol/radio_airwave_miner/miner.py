import time
import random
import threading

class RadioMiner:
    def __init__(self):
        self.shares = {}
        self.lock = threading.Lock()

    def submit_share(self, miner_id):
        with self.lock:
            self.shares[miner_id] = self.shares.get(miner_id, 0) + 1

    def simulate_mining(self):
        miners = ["miner1", "miner2", "miner3"]
        while True:
            time.sleep(random.uniform(0.01, 0.05))
            self.submit_share(random.choice(miners))

    def payout(self):
        while True:
            time.sleep(120)  # every 2 minutes
            with self.lock:
                total_shares = sum(self.shares.values())
                if total_shares == 0:
                    print("No shares submitted in this interval.")
                else:
                    print(f"Payout interval: total shares = {total_shares}")
                    for miner, count in self.shares.items():
                        reward = (count / total_shares) * 100  # 100 Radio tokens total
                        print(f"Paying {miner}: {reward:.4f} Radio tokens")
                self.shares.clear()

if __name__ == "__main__":
    miner = RadioMiner()
    threading.Thread(target=miner.simulate_mining, daemon=True).start()
    threading.Thread(target=miner.payout, daemon=True).start()
    while True:
        time.sleep(1)
