# Dual Miner Protocol

This project provides a dual mining setup for:

- Monero (XMR) mining with XMRig
- Radio Token mining alongside XMR at 100 tokens per 2 minutes

## Setup Instructions

### 1. XMRig Miner Setup

- Download the official XMRig binary for Windows 11 and place it in the `xmrig/` folder.
- Edit `xmrig/config.json`:
  - Set your mining pool URL
  - Set your Monero wallet address
  - Configure thread count as needed

### 2. Radio Token Miner Setup

- Ensure Python 3.8+ is installed.
- Edit `radio_airwave_miner/config.json` with:
  - Your Radio blockchain node URL
  - Your wallet address for Radio tokens
- Run the miner script:
  ```bash
  python radio_airwave_miner/miner.py
  ```

### 3. Launch Both Miners Together

- Run the launcher executable (`launcher.exe`) to start both miners concurrently.

### 4. Payout Bot

- The payout bot runs every 2 minutes to distribute both XMR and Radio token rewards.
- Customize the payout logic in `payout_bot.py` to interact with your blockchain wallets and smart contracts.

## Radio Token Smart Contract

See `RadioToken.sol` for a sample ERC-20 mintable token contract.

## Notes

- Replace placeholders with real URLs and wallet addresses.
- This is a prototype setup. Extend and secure for production use.
